#include "BMPreader.h"

void BMPreader::openBMP(const std::string& file_name) {
	std::filesystem::path file_path = file_name;

	fin.open(file_path, std::ios::binary | std::ios::in);

	if(fin.is_open()) {

		read(fin, bmfh.bfType, sizeof(bmfh.bfType));
		read(fin, bmfh.bfSize, sizeof(bmfh.bfSize));
		read(fin, bmfh.bfReserved1, sizeof(bmfh.bfReserved1));
		read(fin, bmfh.bfReserved2, sizeof(bmfh.bfReserved2));
		read(fin, bmfh.bfOffBits, sizeof(bmfh.bfOffBits));

		read(fin, bmih.biSize, sizeof(bmih.biSize));
		read(fin, bmih.biWidth, sizeof(bmih.biWidth));
		read(fin, bmih.biHeight, sizeof(bmih.biHeight));
		read(fin, bmih.biPlanes, sizeof(bmih.biPlanes));
		read(fin, bmih.biBitCount, sizeof(bmih.biBitCount));
		read(fin, bmih.biCompression, sizeof(bmih.biCompression));
		read(fin, bmih.biSizeImage, sizeof(bmih.biSizeImage));
		read(fin, bmih.biXPelsPerMeter, sizeof(bmih.biXPelsPerMeter));
		read(fin, bmih.biYPelsPerMeter, sizeof(bmih.biYPelsPerMeter));
		read(fin, bmih.biClrUsed, sizeof(bmih.biClrUsed));
		read(fin, bmih.biClrImportant, sizeof(bmih.biClrImportant));

		for (int i = 0; i < bmih.biHeight; ++i) {
			rgb_quad.push_back(std::vector<RGBQUAD>(bmih.biWidth));
		}

		int bytesPerPixel = bmih.biBitCount / 8;
		int rowSize = bmih.biWidth * (bytesPerPixel);
		int padding = (4 - (rowSize % 4)) % 4;


		fin.seekg(bmfh.bfOffBits, std::ios::beg);
		for (int i = 0; i < bmih.biHeight; ++i) {

			std::vector<unsigned char> row(padding + rowSize);
			std::vector<unsigned char>::iterator it;
			fin.read(reinterpret_cast<char*>(row.data()), row.size());
			it = row.begin();

			for (int j = 0; j < bmih.biWidth; ++j) {
				rgb_quad[i][j].rgbBlue = *it++;
				rgb_quad[i][j].rgbGreen = *it++;
				rgb_quad[i][j].rgbRed = *it++;
				if (bytesPerPixel == 3) {
					rgb_quad[i][j].rgbReserved = 0;
				}
				else {
					rgb_quad[i][j].rgbReserved = *it++;
				}

			}
		}

		std::reverse(rgb_quad.begin(), rgb_quad.end());
	}
}

void BMPreader::displayBMP() {

	for (int i = 0; i < bmih.biHeight; ++i) {
		for (int j = 0; j < bmih.biWidth; ++j) {
			if (rgb_quad[i][j].rgbBlue == 0)
				std::cout << "#";  // ������
			else
				std::cout << "-";  // �����
		}
		std::cout << '\n';
	}
}

void BMPreader::closeBMP() {
	fin.close();
}