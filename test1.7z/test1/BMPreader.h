#pragma once

#include <iostream>
#include <fstream>
#include <windows.h> 
#include <string>
#include <filesystem>
#include <algorithm>

class BMPreader {
	std::fstream& fin;
	tagBITMAPFILEHEADER bmfh;
	tagBITMAPINFOHEADER bmih;
	std::vector<std::vector<RGBQUAD>> rgb_quad;

	template <typename T>
	void read(std::fstream& filePath, T& result, size_t size);
public:

	BMPreader() = default;
	BMPreader(std::fstream& in) : fin(in) {}
	~BMPreader() { closeBMP(); }

	void openBMP(const std::string& file_name);
	void displayBMP();
	void closeBMP();
};

template <typename T>
void BMPreader::read(std::fstream& filePath, T& result, size_t size) {
	filePath.read(reinterpret_cast<char*>(&result), size);
}