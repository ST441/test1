#include "BMPreader.h"

int main(int argc, char* argv[]) {

	std::string file_path = argv[1];

	std::fstream fin;

	BMPreader bmp_reader(fin);

	bmp_reader.openBMP(file_path);
	bmp_reader.displayBMP();
	bmp_reader.closeBMP();

	return 0;
}